def main():
    cve_id = "CVE-2024-32002"

    print(f"DB: {DB_PATH}")
    con = init_db()

    print(f"NVD: fetch {cve_id}")
    nvd_json = fetch_cve_from_nvd(cve_id)

    print("NVD: scan references for direct GitHub commit URL")
    commit_url = find_direct_github_commit_url(nvd_json)
    if not commit_url:
        raise RuntimeError("No direct GitHub commit URL found in NVD references for this CVE.")

    print(f"GitHub: {commit_url}")
    owner, repo, sha, diff_text = fetch_commit_diff(commit_url)
    print(f"GitHub: diff bytes={len(diff_text)}")

    print("SQLite: insert patch row")
    save_to_db(con, cve_id, commit_url, owner, repo, sha, diff_text)

    con.close()
    print(f"Done. DB file: {DB_PATH}")
